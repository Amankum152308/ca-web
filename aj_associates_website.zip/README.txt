AJ & Associates - Simple Multi-page Website
-------------------------------------------
Files:
- index.html
- pages/about.html
- pages/services.html
- pages/contact.html
- css/styles.css
- js/main.js
- assets/logo.svg
- images/hero.svg, team.svg

How to use:
1. Unzip the folder.
2. Open index.html in a browser.
3. Edit text/colors/images as needed.
4. To enable real uploads or email, connect forms to your backend or a 3rd-party form service.

Made for the user — deliverable: ZIP file.
